Edge Within Folder Structure
=============================

This is the exact folder system used to organise every episode.

/Raw            - unsorted footage waiting to be filed into an episode folder
/Episodes        - one folder per episode, duplicate "Episode Template" for each new one
  /Episode Template
    /Raw Footage  - original camera/audio files for that specific episode
    /Audio        - audio pulled for Auphonic cleanup
    /Project Files - Premiere Pro project files
/Exports         - final exported long-form episode files, ready to publish
/Clips           - short-form clips pulled from the episode, ready to post

How to use it:
1. Unzip this folder.
2. Rename "Episode Template" to your first episode name, e.g. "Ep01 - Guest Name".
3. Duplicate that folder for every new episode going forward.
4. Keep Raw, Exports, and Clips as shared folders across all episodes.

Get a 1TB SSD and put this whole structure on it before you record anything. It saves headaches later.
